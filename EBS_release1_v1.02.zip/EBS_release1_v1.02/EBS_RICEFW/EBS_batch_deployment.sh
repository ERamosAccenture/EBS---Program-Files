#!/bin/bash
echo "Please enter the SERVER instance name : "
read servername
echo "Enter Username:"
read username
echo "Enter Password:"
read password

insnameLow=$(echo "$servername" | tr '[:upper:]' '[:lower:]')
insnameUp=$(echo "$servername" | tr '[:lower:]' '[:upper:]')


#echo $home
#echo $top
#echo $bin_fndcpesr

home=/interface/j_nbty/$insnameUp/incoming
top=/$insnameLow/applmgr/1200/xxnbty/12.0.0
bin_fndcpesr=/$insnameLow/applmgr/1200/fnd/12.0.0/bin/fndcpesr


#executing all SQL files
sqlplus -s $username/$password <<eof
spool EBS_batch_deployment.log

prompt Executing all create table scripts
prompt 
prompt Executing script xxnbty_opm_batches_tab.sql
	@$top/sql/xxnbty_opm_batches_tab.sql
prompt Executing script xxnbty_bom_headers_tab.sql
	@$top/sql/xxnbty_bom_headers_tab.sql	
prompt Executing script xxnbty_bom_components_tab.sql
	@$top/sql/xxnbty_bom_components_tab.sql
prompt Executing script xxnbty_opm_frmla_commons_tab.sql
	@$top/sql/xxnbty_opm_frmla_commons_tab.sql
prompt Executing script xxnbty_ar_cust_profiles_tab.sql
	@$top/sql/xxnbty_ar_cust_profiles_tab.sql	
prompt Executing script xxnbty_ar_customers_tab.sql
	@$top/sql/xxnbty_ar_customers_tab.sql	
prompt Executing script xxnbty_opm_form_mst_tab.sql
	@$top/sql/xxnbty_opm_form_mst_tab.sql	
prompt Executing script xxnbty_opm_matl_dtl_tab.sql
	@$top/sql/xxnbty_opm_matl_dtl_tab.sql	
prompt Executing script xxnbty_opm_formula_upload_tab.sql
	@$top/sql/xxnbty_opm_formula_upload_tab.sql	
prompt Executing script xxnbty_opm_batch_actions_tab.sql
	@$top/sql/xxnbty_opm_batch_actions_tab.sql	
prompt Executing script xxnbty_opm_batch_headers_tab.sql
	@$top/sql/xxnbty_opm_batch_headers_tab.sql			

prompt Executing all package specs
prompt 
prompt Executing script XXNBTY_OPM_INT02_BATCH_PKG.pks
	@$top/admin/sql/XXNBTY_OPM_INT02_BATCH_PKG.pks
prompt Executing script XXNBTY_BOM_LF08_MAIN_PKG.pks
	@$top/admin/sql/XXNBTY_BOM_LF08_MAIN_PKG.pks
prompt Executing script XXNBTY_AR_INT06_CUSTOMERS_PKG.pks
	@$top/admin/sql/XXNBTY_AR_INT06_CUSTOMERS_PKG.pks
prompt Executing script XXNBTY_OPM_CONV03_FRMLAUPD_PKG.pks
	@$top/admin/sql/XXNBTY_OPM_CONV03_FRMLAUPD_PKG.pks	
prompt Executing script XXNBTY_OPM_CONV03_FRMLAPROCESS_PKG.pks
	@$top/admin/sql/XXNBTY_OPM_CONV03_FRMLAPROCESS_PKG.pks
prompt Executing script XXNBTY_OPM_CONV03_TRANSFORM_PKG.pks
	@$top/admin/sql/XXNBTY_OPM_CONV03_TRANSFORM_PKG.pks
prompt Executing script XXNBTY_OPM_CONV03_FMLALOAD_PKG.pks
	@$top/admin/sql/XXNBTY_OPM_CONV03_FMLALOAD_PKG.pks
prompt Executing script XXNBTY_EBS_SEND_EMAIL_PKG.pks
	@$top/admin/sql/XXNBTY_EBS_SEND_EMAIL_PKG.pks	
	
prompt Executing all package body
prompt 

prompt Executing script XXNBTY_OPM_INT02_BATCH_PKG.pkb
	@$top/admin/sql/XXNBTY_OPM_INT02_BATCH_PKG.pkb
prompt Executing script XXNBTY_BOM_LF08_MAIN_PKG.pkb
	@$top/admin/sql/XXNBTY_BOM_LF08_MAIN_PKG.pkb
prompt Executing script XXNBTY_AR_INT06_CUSTOMERS_PKG.pkb
	@$top/admin/sql/XXNBTY_AR_INT06_CUSTOMERS_PKG.pkb
prompt Executing script XXNBTY_OPM_CONV03_FRMLAUPD_PKG.pkb
	@$top/admin/sql/XXNBTY_OPM_CONV03_FRMLAUPD_PKG.pkb
prompt Executing script XXNBTY_OPM_CONV03_FRMLAPROCESS_PKG.pkb
	@$top/admin/sql/XXNBTY_OPM_CONV03_FRMLAPROCESS_PKG.pkb
prompt Executing script XXNBTY_OPM_CONV03_TRANSFORM_PKG.pkb
	@$top/admin/sql/XXNBTY_OPM_CONV03_TRANSFORM_PKG.pkb	
prompt Executing script XXNBTY_OPM_CONV03_FMLALOAD_PKG.pkb
	@$top/admin/sql/XXNBTY_OPM_CONV03_FMLALOAD_PKG.pkb
prompt Executing script XXNBTY_EBS_SEND_EMAIL_PKG.pkb
	@$top/admin/sql/XXNBTY_EBS_SEND_EMAIL_PKG.pkb
	
spool off
eof
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

#converting all Unix files

echo "Converting all Unix files" >> $home/EBS_RICEFW/EBS_batch_deployment.log
echo "" >> EBS_batch_deployment.log
dos2unix $top/bin/XXNBTYINT02.prog >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
dos2unix $top/bin/XXNBTYINT06.prog >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
dos2unix $top/bin/XXNBTYLF08.prog >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
dos2unix $top/bin/XXNBTYCONV03.prog >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
dos2unix $top/bin/XXNBTYEBSSENDEMAIL.prog >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
echo "" >> EBS_batch_deployment.log

#creating Symbolic Links
echo "Creating Symbolic links" >> EBS_batch_deployment.log
echo "" >> EBS_batch_deployment.log
cd $top/bin
ln -s $bin_fndcpesr XXNBTYINT02 >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
ln -s $bin_fndcpesr XXNBTYINT06 >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
ln -s $bin_fndcpesr XXNBTYLF08 >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
ln -s $bin_fndcpesr XXNBTYCONV03 >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
ln -s $bin_fndcpesr XXNBTYEBSSENDEMAIL >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
cd $home/EBS_RICEFW
echo "" >> EBS_batch_deployment.log

#uploading all FND files
echo "Uploading all FND files" >> EBS_batch_deployment.log
echo "" >> EBS_batch_deployment.log

cd $top/admin/import
#function to upload concurrent program
function upload_cp(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct $1 UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

#function to upload value set
function upload_vs(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password 0 Y UPLOAD $FND_TOP/patch/115/import/afffload.lct $1 CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

#function to upload request set
function upload_rs(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password 0 Y UPLOAD $FND_TOP/patch/115/import/afcprset.lct $1 CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

#function to upload request set links
function upload_rsl(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password 0 Y UPLOAD $FND_TOP/patch/115/import/afcprset.lct $1 CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

#function to upload request set group
function upload_rsg(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password 0 Y UPLOAD $FND_TOP/patch/115/import/afcpreqg.lct $1 CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

#function to upload lookup
function upload_lkp(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password 0 Y UPLOAD $FND_TOP/patch/115/import/aflvmlu.lct $1 CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

#function to upload menu
function upload_menu(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password 0 Y UPLOAD $FND_TOP/patch/115/import/afsload.lct $1 CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

#function to upload responsibility
function upload_resp(){
	echo "Uploading $1..." >> ../EBS_batch_deployment.log
	FNDLOAD $username/$password O Y UPLOAD $FND_TOP/patch/115/import/afscursp.lct $1 CUSTOM_MODE=FORCE >> $home/EBS_RICEFW/EBS_batch_deployment.log 2>&1
}

echo "Uploading Oracle Send Email" >> $home/EBS_RICEFW/EBS_batch_deployment.log
upload_vs XXNBTY_EBS_PROCESS_ERROR_VS.ldt
upload_vs XXNBTY_EBS_SEND_EMAIL_VS.ldt
upload_lkp XXNBTY_EBS_SEND_EMAIL_LT.ldt
upload_cp XXNBTY_EBS_PROCESS_ERROR_CP.ldt
upload_cp XXNBTY_EBS_SEND_EMAIL_CP.ldt
upload_rsg XXNBTY_EBS_PROCESS_ERROR_RG.ldt
upload_rsg XXNBTY_EBS_SEND_EMAIL_RG.ldt
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

echo "Uploading CONV03 - OPM Formula" >> $home/EBS_RICEFW/EBS_batch_deployment.log
upload_lkp XXNBTY_CONV03_LT.ldt
upload_cp XXNBTY_CONV03_CP_a.ldt
upload_cp XXNBTY_CONV03_CP_b.ldt
upload_cp XXNBTY_CONV03_CP_c.ldt
upload_rs XXNBTY_CONV03_RS.ldt
upload_rsl XXNBTY_CONV03_RL.ldt
upload_rsg XXNBTY_CONV03_RG.ldt
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

echo "Uploading INT02 - Batch Transaction Inbound Interface" >> $home/EBS_RICEFW/EBS_batch_deployment.log
upload_cp XXNBTY_INT02_CP_a.ldt
upload_cp XXNBTY_INT02_CP_b.ldt
upload_cp XXNBTY_INT02_CP_c.ldt
upload_cp XXNBTY_INT02_CP_d.ldt
upload_rs XXNBTY_INT02_RS.ldt
upload_rsl XXNBTY_INT02_RL.ldt
upload_rsg XXNBTY_INT02_RG.ldt
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

echo "Uploading INT06 - On-Going Customer Interface" >> $home/EBS_RICEFW/EBS_batch_deployment.log
upload_cp XXNBTY_INT06_CP_a.ldt
upload_cp XXNBTY_INT06_CP_b.ldt
upload_cp XXNBTY_INT06_CP_c.ldt
upload_cp XXNBTY_INT06_CP_d.ldt
upload_rs XXNBTY_INT06_RS.ldt
upload_rsl XXNBTY_INT06_RL.ldt
upload_rsg XXNBTY_INT06_RG.ldt
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

echo "Uploading LF08 - Oracle Inbound Data Files for BOM Data" >> $home/EBS_RICEFW/EBS_batch_deployment.log
upload_cp XXNBTY_LF08_CP_a.ldt
upload_cp XXNBTY_LF08_CP_b.ldt
upload_cp XXNBTY_LF08_CP_c.ldt
upload_cp XXNBTY_LF08_CP_d.ldt
upload_cp XXNBTY_LF08_CP_e.ldt
upload_rs XXNBTY_LF08_RS.ldt
upload_rsl XXNBTY_LF08_RL.ldt
upload_rsg XXNBTY_LF08_RG.ldt
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

echo "Uploading EBS Menu" >> $home/EBS_RICEFW/EBS_batch_deployment.log
upload_menu XXNBTY_BOM_MAINTAINANCE_MU.ldt
upload_menu ONT_CUSTOMERS_MU.ldt
upload_menu BOM_NAVIGATE_GUI_MU.ldt
upload_menu XXNBTY_INVENTORY_MU.ldt
upload_menu XXNBTY_OPM_ADMIN_MU.ldt
upload_menu XXNBTY_OPM_PRODUCTION_USER_MU.ldt
upload_menu PO_SUPPLY_BASE_GUI_MU.ldt
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

echo "Uploading EBS Menu" >> $home/EBS_RICEFW/EBS_batch_deployment.log
upload_resp NBTY_BOM_MAINTAIN_UR.ldt
upload_resp XXNBTY_CUSTOMER_MAINTAINANCE_UR.ldt
upload_resp NBTY_IT_BOM_OWNER_UR.ldt 
upload_resp XXNBTY_INVENTORY_USER_UR.ldt 
upload_resp NBTY_OPM_ADMIN_USER_UR.ldt 
upload_resp NBTY_OPM_PRODUCTION_USER_UR.ldt 
upload_resp XXNBTY_SOURCING_RULES_UR.ldt
echo "" >> $home/EBS_RICEFW/EBS_batch_deployment.log

exit 0