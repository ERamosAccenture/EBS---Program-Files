#!/bin/bash
echo "Please enter the SERVER instance name : "
read servername

insnameLow=$(echo "$servername" | tr '[:upper:]' '[:lower:]')
insnameUp=$(echo "$servername" | tr '[:lower:]' '[:upper:]')

home=/interface/j_nbty/$insnameUp/incoming
top=/$insnameLow/applmgr/1200/xxnbty/12.0.0
#echo $home
#echo $top

#setting permission for all user
echo "Setting permission for all user" > EBS_set_permission.log
echo "" >> EBS_set_permission.log
chmod 777 -R $home/EBS_RICEFW
chmod 777 $top/bin/XXNBTYINT02.prog >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/XXNBTYINT06.prog >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/XXNBTYLF08.prog >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/XXNBTYCONV03.prog >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/XXNBTYEBSSENDEMAIL.prog >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/lf08_bom_comp.ctl >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/lf08_bom_header.ctl >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/int002.ctl >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/int006.ctl >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
chmod 777 $top/bin/conv003.ctl >> $home/EBS_RICEFW/EBS_set_permission.log 2>&1
cd $home/EBS_RICEFW
echo "Finished setting permission for all user" >> EBS_set_permission.log
echo "" >> EBS_set_permission.log