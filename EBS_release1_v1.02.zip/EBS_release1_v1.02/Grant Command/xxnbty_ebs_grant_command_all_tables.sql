--------------------------------------------------------------------------------------------
/*
Script Name: xxnbty_ebs_grant_command_all_tables
Date written: 10-Mar-2015	
RICEFW Object: N/A
Description: Grant command of all EBS staging tables to APPS user.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
10-Mar-2015				 	Erwin Ramos				Initial Development


*/
--------------------------------------------------------------------------------------------
DECLARE 

BEGIN 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_ar_cust_profiles_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_ar_customers_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_bom_components_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_bom_headers_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_opm_batch_actions_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_opm_batch_headers_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_opm_batches_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_opm_form_mst_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_opm_formula_upload TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_opm_frmla_commons_st TO APPS'; 
	EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, DELETE, UPDATE ON xxnbty.xxnbty_opm_matl_dtl_st TO APPS'; 
END; 
/
show errors;
