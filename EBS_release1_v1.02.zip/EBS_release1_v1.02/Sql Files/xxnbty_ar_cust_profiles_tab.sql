--------------------------------------------------------------------------------------------
/*
Table Name: xxnbty_ar_cust_profiles_st
Author's Name: Albert John Flores
Date written: 17-Nov-2014
RICEFW Object: LF04
Description: Staging table for customer profile.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
17-Nov-2014				 	Albert John Flores		Initial Development


*/
--------------------------------------------------------------------------------------------
CREATE TABLE xxnbty.xxnbty_ar_cust_profiles_st
  (
    insert_update_flag              VARCHAR2(1)
    ,orig_system_customer_ref        VARCHAR2(240)
    ,customer_profile_class_name     VARCHAR2(30)  DEFAULT 'DEFAULT'
    ,credit_hold                     VARCHAR2(1)   DEFAULT 'N'
    ,org_id                          NUMBER
    ,record_id                       NUMBER
    ,record_status                   VARCHAR2(10)
    ,interface_status                VARCHAR2(10)
    ,last_update_date                DATE
    ,last_updated_by                 NUMBER
    ,creation_date                   DATE
    ,created_by                      NUMBER
    ,last_update_login               NUMBER
    ,request_id                  	NUMBER
  );
  
  --[PUBLIC SYNONYM xxnbty_ar_cust_profiles_st]
CREATE OR REPLACE PUBLIC SYNONYM xxnbty_ar_cust_profiles_st for xxnbty.xxnbty_ar_cust_profiles_st;
