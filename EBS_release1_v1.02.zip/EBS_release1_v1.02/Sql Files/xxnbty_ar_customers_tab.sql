
--------------------------------------------------------------------------------------------
/*
Table Name: xxnbty_ar_customers_st
Author's Name: Albert John Flores
Date written: 17-Nov-2014
RICEFW Object: LF04
Description: Staging table for customers.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
17-Nov-2014				 	Albert John Flores		Initial Development


*/
--------------------------------------------------------------------------------------------
CREATE TABLE xxnbty.xxnbty_ar_customers_st
  ( 
    insert_update_flag          VARCHAR2(1)
    ,orig_system_customer_ref    VARCHAR2(240)
    ,site_use_code               VARCHAR2(30)
    ,orig_system_address_ref     VARCHAR2(240)
    ,customer_name               VARCHAR2(360)
    ,customer_number             VARCHAR2(30) DEFAULT NULL
    ,customer_status             VARCHAR2(1) DEFAULT 'A'
    ,primary_site_use_flag       VARCHAR2(1) DEFAULT 'Y'
    ,location                    VARCHAR2(40) DEFAULT NULL
    ,address1                    VARCHAR2(240)
    ,address2                    VARCHAR2(240)    
    ,address3                    VARCHAR2(240)
    ,address4                    VARCHAR2(240)
    ,city                        VARCHAR2(60)
    ,state                       VARCHAR2(60) 
    ,postal_code                 VARCHAR2(60)
    ,country                     VARCHAR2(60)
    ,customer_category_code      VARCHAR2(30) DEFAULT 'CUSTOMER'
    ,province                    VARCHAR2(60)
    ,county                      VARCHAR2(60)
    ,org_id                      NUMBER
    ,record_id                   NUMBER
    ,record_status               VARCHAR2(10)
    ,interface_status            VARCHAR2(10)
    ,last_update_date            DATE
    ,last_update_by              NUMBER
    ,creation_date               DATE
    ,created_by                  NUMBER
    ,last_update_login           NUMBER
	,last_updated_by             NUMBER
    ,error_message               VARCHAR2(2000)
    ,process_flag                VARCHAR2(10)
    ,request_id                  NUMBER
  );
  
  --[PUBLIC SYNONYM xxnbty_ar_customers_st]
CREATE OR REPLACE PUBLIC SYNONYM xxnbty_ar_customers_st for xxnbty.xxnbty_ar_customers_st;
