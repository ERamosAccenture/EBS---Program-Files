--------------------------------------------------------------------------------------------
/*
Table Name: xxnbty_opm_batch_actions_st
Author's Name: Erwin Ramos
Date written: 01-Dec-2014
RICEFW Object: INT02
Description: Staging table for opm batch actions.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
01-Dec-2014				 	Erwin Ramos				Initial Development


*/
--------------------------------------------------------------------------------------------
CREATE TABLE xxnbty.xxnbty_opm_batch_actions_st
(
INTERFACE_ID               NUMBER      NOT NULL  
,ORGANIZATION_CODE                  VARCHAR2(3)   
,BATCH_NO                           VARCHAR2(32)  
,BATCHSTEP_NO                       NUMBER(10) 
,INT_ORGANIZATION_ID                NUMBER        
,BATCH_ID                           NUMBER(10)    
,INT_BATCH_ID                       NUMBER(10)    
,BATCHSTEP_ID                       NUMBER(15)    
,INT_BATCHSTEP_ID                   NUMBER(15)    
,ACTUAL_START_DATE                  DATE          
,ACTUAL_CMPLT_DATE                  DATE          
,CLOSE_DATE                         DATE          
,IGNORE_MATERIAL_EXCEPTION          VARCHAR2(1)   
,TERMINATE_REASON_ID                NUMBER(10)    
,INT_TERMINATE_REASON_ID            NUMBER(10)    
,TERMINATE_REASON_CODE              VARCHAR2(30)  
,CREATE_RESV_PEND_LOTS              NUMBER(2)     
,CONTINUE_LPN_TXN                   VARCHAR2(1)   
,REOPEN_STEPS                       VARCHAR2(1)   
,CREATED_BY                         NUMBER(15)    
,CREATION_DATE                      DATE DEFAULT (sysdate)          
,LAST_UPDATE_DATE                   DATE DEFAULT (sysdate)          
,LAST_UPDATE_LOGIN                  NUMBER(15)    
,LAST_UPDATED_BY                    NUMBER(15)    
,GROUP_ID                           NUMBER(15)    
,REQUEST_ID                         NUMBER(15)    
,PROCESS_PHASE                      VARCHAR2(32)  
,PROCESS_STATUS                     VARCHAR2(32)  
,OBJECT_TYPE                NUMBER(3) NOT NULL    
,ACTION                     NUMBER(3) NOT NULL    
,PROCESS_FLAG                       VARCHAR2(2)   
,LEGACY_BATCH_NO                    VARCHAR2(240) 
);

  --[PUBLIC SYNONYM xxnbty_opm_batch_actions_st]
CREATE OR REPLACE PUBLIC SYNONYM xxnbty_opm_batch_actions_st for xxnbty.xxnbty_opm_batch_actions_st;
