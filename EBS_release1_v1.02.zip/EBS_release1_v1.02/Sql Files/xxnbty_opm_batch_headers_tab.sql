--------------------------------------------------------------------------------------------
/*
Table Name: xxnbty_opm_batch_headers_st
Author's Name: Erwin Ramos
Date written: 01-Dec-2014
RICEFW Object: INT02
Description: Staging table for opm batch headers.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
01-Dec-2014				 	Erwin Ramos				Initial Development


*/
--------------------------------------------------------------------------------------------

CREATE TABLE xxnbty.xxnbty_opm_batch_headers_st 
(
INTERFACE_HEADER_ID       NUMBER    NOT NULL    
,ORGANIZATION_CODE                 VARCHAR2(3)   
,ORGANIZATION_ID                   NUMBER        
,BATCH_NO                          VARCHAR2(32)  
,BATCH_ID                          NUMBER(10)    
,INT_BATCH_ID                      NUMBER(10)    
,RECIPE_VALIDITY_RULE_ID           NUMBER(10)    
,RECIPE_ID                         NUMBER(10)    
,INT_RECIPE_ID                     NUMBER(10)    
,RECIPE_NO                         VARCHAR2(32)  
,RECIPE_VERS                       NUMBER(5)     
,PLAN_START_DATE                   DATE          
,ACTUAL_START_DATE                 DATE          
,DUE_DATE                          DATE          
,PLAN_CMPLT_DATE                   DATE          
,ACTUAL_CMPLT_DATE                 DATE          
,BATCH_SIZE                        NUMBER        
,BATCH_SIZE_UOM                    VARCHAR2(4)   
,CREATION_MODE                     NUMBER(5)     
,INVENTORY_ITEM_ID                 NUMBER        
,INT_INVENTORY_ITEM_ID             NUMBER        
,ITEM                              VARCHAR2(300) 
,ITEM_REVISION                     VARCHAR2(3)   
,UPDATE_INVENTORY_IND              VARCHAR2(1)   
,FIRMED_IND                        NUMBER(5)     
,LABORATORY_IND                    NUMBER(1)     
,INT_ORGANIZATION_ID               NUMBER        
,USE_WORKDAY_CAL                   VARCHAR2(1)   
,IGNORE_QTY_BELOW_CAP              VARCHAR2(1)   
,CONTIGUITY_OVERRIDE               VARCHAR2(1)   
,USE_LEAST_COST_VR                 VARCHAR2(1)   
,APPLY_FIXED_PROCESS_LOSS          VARCHAR2(1)   
,ATTRIBUTE1                        VARCHAR2(240) 
,ATTRIBUTE2                        VARCHAR2(240) 
,ATTRIBUTE3                        VARCHAR2(240) 
,ATTRIBUTE4                        VARCHAR2(240) 
,ATTRIBUTE5                        VARCHAR2(240) 
,ATTRIBUTE6                        VARCHAR2(240) 
,ATTRIBUTE7                        VARCHAR2(240) 
,ATTRIBUTE8                        VARCHAR2(240) 
,ATTRIBUTE9                        VARCHAR2(240) 
,ATTRIBUTE10                       VARCHAR2(240) 
,ATTRIBUTE11                       VARCHAR2(240) 
,ATTRIBUTE12                       VARCHAR2(240) 
,ATTRIBUTE13                       VARCHAR2(240) 
,ATTRIBUTE14                       VARCHAR2(240) 
,ATTRIBUTE15                       VARCHAR2(240) 
,ATTRIBUTE16                       VARCHAR2(240) 
,ATTRIBUTE17                       VARCHAR2(240) 
,ATTRIBUTE18                       VARCHAR2(240) 
,ATTRIBUTE19                       VARCHAR2(240) 
,ATTRIBUTE20                       VARCHAR2(240) 
,ATTRIBUTE21                       VARCHAR2(240) 
,ATTRIBUTE22                       VARCHAR2(240) 
,ATTRIBUTE23                       VARCHAR2(240) 
,ATTRIBUTE24                       VARCHAR2(240) 
,ATTRIBUTE25                       VARCHAR2(240) 
,ATTRIBUTE26                       VARCHAR2(240) 
,ATTRIBUTE27                       VARCHAR2(240) 
,ATTRIBUTE28                       VARCHAR2(240) 
,ATTRIBUTE29                       VARCHAR2(240) 
,ATTRIBUTE30                       VARCHAR2(240) 
,ATTRIBUTE31                       VARCHAR2(240) 
,ATTRIBUTE32                       VARCHAR2(240) 
,ATTRIBUTE33                       VARCHAR2(240) 
,ATTRIBUTE34                       VARCHAR2(240) 
,ATTRIBUTE35                       VARCHAR2(240) 
,ATTRIBUTE36                       VARCHAR2(240) 
,ATTRIBUTE37                       VARCHAR2(240) 
,ATTRIBUTE38                       VARCHAR2(240) 
,ATTRIBUTE39                       VARCHAR2(240) 
,ATTRIBUTE40                       VARCHAR2(240) 
,ATTRIBUTE_CATEGORY                VARCHAR2(30)  
,LAST_UPDATE_DATE                  DATE          
,LAST_UPDATED_BY                   NUMBER(15)    
,CREATION_DATE                     DATE          
,CREATED_BY                        NUMBER(15)    
,LAST_UPDATE_LOGIN                 NUMBER(15)    
,GROUP_ID                          NUMBER(15)    
,REQUEST_ID                        NUMBER(15)    
,PROCESS_PHASE                     VARCHAR2(32)  
,PROCESS_STATUS                    VARCHAR2(32)  
,LOAD_TYPE                 NUMBER(3)     NOT NULL
,PROCESS_FLAG                      VARCHAR2(2)   
);

  --[PUBLIC SYNONYM xxnbty_opm_batch_headers_st]
CREATE OR REPLACE PUBLIC SYNONYM xxnbty_opm_batch_headers_st for xxnbty.xxnbty_opm_batch_headers_st;
