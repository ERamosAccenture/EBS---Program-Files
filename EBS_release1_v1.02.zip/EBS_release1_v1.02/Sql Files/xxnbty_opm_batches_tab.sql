--------------------------------------------------------------------------------------------
/*
Table Name: XXNBTY_OPM_BATCHES_ST
Author's Name: Erwin Ramos
Date written: 01-Dec-2014
RICEFW Object: INT02
Description: Staging table for opm batches.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
01-Dec-2014				 	Erwin Ramos				Initial Development


*/
--------------------------------------------------------------------------------------------

CREATE TABLE xxnbty.xxnbty_opm_batches_st 
(
ORGANIZATION_CODE VARCHAR2(3) NOT NULL
,PLAN_START_DATE DATE
,PLAN_CMPLT_DATE DATE
,DUE_DATE DATE
,BATCH_SIZE VARCHAR2(240) NOT NULL
,BATCH_SIZE_UOM VARCHAR2(240) NOT NULL
,ITEM  VARCHAR2(300) NOT NULL
,ITEM_REVISION  VARCHAR2(3)
,AS400_BATCH_NUM  VARCHAR2(240) NOT NULL
,LOAD_TYPE  NUMBER(3) NOT NULL
,BATCH_STATUS  VARCHAR2(240) NOT NULL
,ACTUAL_START_DATE  DATE
,ACTUAL_CMPLT_DATE  DATE
,PROCESS_FLAG NUMBER(3)
,LAST_UPDATE_DATE DATE DEFAULT (sysdate)
,CREATION_DATE DATE DEFAULT (sysdate)
,CREATED_BY NUMBER
,LAST_UPDATED_BY NUMBER
,LAST_UPDATE_LOGIN NUMBER
,ERROR_DESCRIPTION VARCHAR2(1000)
);

--[PUBLIC SYNONYM xxnbty_opm_batches_st]
CREATE OR REPLACE PUBLIC SYNONYM xxnbty_opm_batches_st for xxnbty.xxnbty_opm_batches_st;