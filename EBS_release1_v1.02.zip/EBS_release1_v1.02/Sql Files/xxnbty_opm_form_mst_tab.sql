--------------------------------------------------------------------------------------------
/*
Table Name: xxnbty_opm_form_mst_st
Author's Name: Ronald Villavieja
Date written: 01-Dec-2014
RICEFW Object: CONV03
Description: Staging table for xxnbty_opm_form_mst_st formula.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
01-Dec-2014				 	Ronald Villavieja			Initial Development


*/
--------------------------------------------------------------------------------------------


  CREATE TABLE xxnbty.xxnbty_opm_form_mst_st 
   (	FORMULA_NO VARCHAR2(32) NOT NULL, 
	FORMULA_VERS NUMBER NOT NULL, 
	FORMULA_TYPE NUMBER(5,0) NOT NULL, 
	SCALE_TYPE NUMBER(5,0) NOT NULL, 
	INACTIVE_IND NUMBER(5,0) NOT NULL, 
	ORGN_CODE VARCHAR2(4) NOT NULL, 
	FORMULA_STATUS VARCHAR2(30) NOT NULL, 
	YIELD_UOM VARCHAR2(3), 
	FORMULA_DESC1 VARCHAR2(70), 
	DELETE_MARK NUMBER(5,0), 
	OWNER_ORGANIZATION_ID NUMBER(15,0), 
	STATUS VARCHAR2(1), 
	ERROR_TEXT VARCHAR2(2000), 
	RECORD_TYPE_ACTION VARCHAR2(1), 
	FORMULA_ID NUMBER(10,0), 
	FILESET NUMBER NOT NULL, 
	FILENAME VARCHAR2(50)
   );
--[PUBLIC SYNONYM xxnbty_opm_form_mst_st]
CREATE OR REPLACE PUBLIC SYNONYM xxnbty_opm_form_mst_st for xxnbty.xxnbty_opm_form_mst_st;
