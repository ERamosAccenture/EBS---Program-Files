--------------------------------------------------------------------------------------------
/*
Table Name: xxnbty_opm_matl_dtl_st
Author's Name: Ronald Villavieja
Date written: 01-Dec-2014
RICEFW Object: CONV03
Description: Staging table for xxnbty_opm_matl_dtl_st formula.
Program Style: 

Maintenance History: 

Date			Issue#		Name					Remarks	
-----------		------		-----------				------------------------------------------------
01-Dec-2014				 	Ronald Villavieja			Initial Development


*/
--------------------------------------------------------------------------------------------

  CREATE TABLE xxnbty.xxnbty_opm_matl_dtl_st
   (	FORMULA_NO VARCHAR2(32) NOT NULL, 
	FORMULA_VERS NUMBER NOT NULL, 
	LINE_TYPE NUMBER(5,0) NOT NULL, 
	LINE_NO NUMBER(5,0) NOT NULL, 
	QTY NUMBER NOT NULL, 
	ITEM_UM VARCHAR2(4), 
	RELEASE_TYPE NUMBER(5,0) NOT NULL, 
	SCRAP_FACTOR NUMBER NOT NULL, 
	SCALE_TYPE NUMBER(5,0) NOT NULL, 
	PHANTOM_TYPE NUMBER(5,0) NOT NULL, 
	CONTRIBUTE_STEP_QTY_IND VARCHAR2(1), 
	CONTRIBUTE_YIELD_IND VARCHAR2(1), 
	SCALE_MULTIPLE NUMBER, 
	DETAIL_UOM VARCHAR2(3) NOT NULL, 
	REVISION VARCHAR2(3), 
	INGREDIENT_END_DATE DATE, 
	COST_ALLOC NUMBER, 
	ATTRIBUTE_CATEGORY VARCHAR2(30), 
	INVENTORY_ITEM_ID VARCHAR2(40) NOT NULL, 
	ORGANIZATION_ID NUMBER(15,0) NOT NULL, 
	STATUS VARCHAR2(1) NOT NULL, 
	ERROR_TEXT VARCHAR2(2000), 
	FILESET NUMBER NOT NULL, 
	FILENAME VARCHAR2(50)
   );
--[PUBLIC SYNONYM xxnbty_opm_matl_dtl_st]
CREATE OR REPLACE PUBLIC SYNONYM xxnbty_opm_matl_dtl_st for xxnbty.xxnbty_opm_matl_dtl_st;

